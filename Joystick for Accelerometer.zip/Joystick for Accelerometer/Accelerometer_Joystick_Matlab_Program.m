clear device
%%%%check the COM number. If you are using other ports please modify the
%%%%following code
serial = serialport("COM3",9600);

figure;
%%%%loops for 1000 times
for i = 1:1000
    str_arr = split(readline(serial));
    x = str2double(str_arr(1));
    y = str2double(str_arr(2));
    z = str2double(str_arr(3));
    plot3(x,y,z,'o');
    disp(x)
    disp(y)
    disp(z)
    %%%%change the following code to make sure your acceleration values do
    %%%%not overflow in each directions. (The default limit is from 1 to 
    % 1024)
    xlim([0,1024]);
    ylim([0,1024]);
    zlim([0,1024]);
    grid on
    drawnow
    pause(1)
    disp(i)
end
clear device